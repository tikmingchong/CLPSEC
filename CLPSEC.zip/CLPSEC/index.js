const https = require('https');

//MQTT BROKER INFO-START
const mqtt = require('mqtt')

const host = 'broker.emqx.io'
const port = '1883'
const connectUrl = `mqtt://${host}:${port}`
const client = mqtt.connect(connectUrl, {
    clean: true,
    connectTimeout: 4000,
    reconnectPeriod: 1000,
    retain: true
})

//MQTT BROKER INFO-END

///*Q1A+B -START
https.get('https://data.weather.gov.hk/weatherAPI/opendata/weather.php?dataType=rhrread&lang=en', (resp) => {
   

    let data = '';

    // A chunk of data has been received.
    resp.on('data', (chunk) => {
        data += chunk;
    });

    // The whole response has been received. Print out the result.
    resp.on('end', () => {
        
        let dataB = '';
        

        dataB = (JSON.parse(data).temperature);
           
        
        
        let array = [];
        array = dataB.data;
        //Q1a.	Use Hong Kong Observatory API to retrieve current temperatures for all districts and output a human-readable format to screen - START
        console.log('Q1a');
        console.log('------------------');

        //initialize q3 output        
        let msgA = '';

        for (let i = 0; i < array.length; i++) {          
                 
            msgA = msgA + array[i].place + ' is ' + array[i].value + '\u00B0' + array[i].unit + "\n";
          
        }
 ///#Q3a- START
        console.log(msgA);
        client.on('connect', () => {            
            client.publish('clpsec/weather_forecast/all', msgA, { qos: 0, retain: false }, (error) => {
                if (error) {
                    console.error(error)
                }
            })            
        })
///#Q3a- END
        //Q1a.	Use Hong Kong Observatory API to retrieve current temperatures for all districts and output a human-readable format to screen - END
        //Q1b.	Use the same API to get current temperatures for Shatin only and output a human-readable format to screen.  - START
        
        //initialize q3 output
        let msgB = '';

        console.log('------------------');
        console.log('Q1b');
        console.log('------------------');
        for (let i = 0; i < array.length; i++) {
            if (array[i].place == 'Sha Tin') {
                msgB = msgB + array[i].place + ' is ' + array[i].value + '\u00B0' + array[i].unit;
                //console.log(array[i].place, 'is', array[i].value, '\u00B0', array[i].unit);
                console.log(msgB);
///#Q3b- START

                client.on('connect', () => {
                    client.publish('clpsec/weather_forecast/shatin', msgB, { qos: 0, retain: false }, (error) => {
                        if (error) {
                            console.error(error)
                        }
                    })
                    
                    //client.end();
                })   
///#Q3b- END
                
            }
            
        }
       
        
        //Q1b.	Use the same API to get current temperatures for Shatin only and output a human-readable format to screen.  - END    
    });

    

}).on("error", (err) => {
    console.log("Error: " + err.message);
});

//END * /
///*Q1C -START
https.get('https://data.weather.gov.hk/weatherAPI/opendata/weather.php?dataType=fnd&lang=en', (resp) => {
    let data = '';

    // A chunk of data has been received.
    resp.on('data', (chunk) => {
        data += chunk;
    });

    // The whole response has been received. Print out the result.
    resp.on('end', () => {

        let dataB = '';
        let msgC = '';

        dataB = (JSON.parse(data).weatherForecast);

        

        //Q1c.	Use the weather forecast API to get 3-days (excluding today) forecasting and output to the screen in the following format.  - START
        console.log('------------------');
        console.log('Q1c');
        console.log('------------------');
        
        msgC += 'Next 3-day weather forecast:\n';
        msgC += '---------\n';
        let arrayF = [];
        arrayF = dataB;       
        for (let i = 0; i < 3; i++) {
            let week = '';
            let year = '';
            let month = '';
            let day = '';
            week = arrayF[i].week.substring(0, 3);
            year = arrayF[i].forecastDate.substring(0, 4);
            month = arrayF[i].forecastDate.substring(4, 6);
            day = arrayF[i].forecastDate.substring(6, 8);
          
            msgC += week+ ' (Date of '+ year+ '-'+ month+ '-'+ day+ ')\n';
           
            msgC += '>> Temperature:\n';
           
            msgC += '>>>> Max.: ' + arrayF[i].forecastMaxtemp.value + '\u00B0' + arrayF[i].forecastMaxtemp.unit + '\n';
         
            msgC += '>>>> Min: ' + arrayF[i].forecastMaxtemp.value + '\u00B0' + arrayF[i].forecastMaxtemp.unit + '\n';
         
            msgC += '>> Humidity:\n';
           
           msgC += '>>>> Max.: ' + arrayF[i].forecastMaxrh.value + '%\n';
           
            msgC += '>>>> Min: ' + arrayF[i].forecastMinrh.value + '%\n';            
            msgC += '----------\n';
          
            
        }    
        console.log(msgC);
 ///#Q3c- START

        client.on('connect', () => {            
            client.publish('clpsec/weather_forecast/3_day', msgC, { qos: 0, retain: false }, (error) => {
                if (error) {
                    console.error(error)
                }
            })
            client.end();
        })
///#Q3c- END

        
        




    });






}).on("error", (err) => {
    console.log("Error: " + err.message);
});
 //END * /


///*Q3 -START
console.log('------------------');
console.log('Q3 publised on host = "broker.emqx.io" and port = 1883');
console.log('------------------');
///*Q3 -END

///*Q2 -START
console.log('------------------');
console.log('Q2:');
console.log('------------------');

const event2 = new Date('Sep 18, 2021');
console.log('a. the ISO8601 format of the "Sep 18, 2021" : ');
console.log(event2.toISOString());
console.log();
const event3 = new Date('2021-09-18');
console.log('b. the ISO8601 format of the "2021-09-18" : ');
console.log(event3.toISOString());
console.log();
const event4 = new Date('18 September 2021');
console.log('c. the ISO8601 format of the "18 September 2021" : ');
console.log(event4.toISOString());
console.log();
const event5 = new Date('Sep 18, 2021, 12:00pm');
console.log('d. the ISO8601 format of the "Sep 18, 2021, 12:00pm" : ');

console.log(event5);
console.log('Invalid time value');
console.log();
const event6 = new Date('2021-09-18 13:00');
console.log('e. the ISO8601 format of the "2021-09-18 13:00" : ');
console.log(event6.toISOString());
console.log();
console.log('------------------');
///*Q2 -END








